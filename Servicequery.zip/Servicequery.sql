use Training_19Sep19_Pune
go

create table [46008527].ServiceCenter
(
ServiceID varchar(6) primary key,
RequestDate Date not null,
OwnerName varchar(50) not null,
ContactNo varchar(10) not null,
DeviceType varchar(50) not null,
SerialNo varchar(14) not null,
IssueDescription varchar(150) not null
)


create procedure [46008527].SubmitRequest
@ServiceID varchar(6),
@RequestDate Date,
@OwnerName varchar(50),
@ContactNo varchar(10),
@DeviceType varchar(50),
@SerialNo varchar(14),
@IssueDescription varchar(150)
AS
BEGIN
	  insert into [46008527].ServiceCenter values(@ServiceID, @RequestDate,@OwnerName,@ContactNo,@DeviceType,@SerialNo,@IssueDescription)
END
GO

create procedure [46008527].SelectRequest
AS
BEGIN
select * from [46008527].ServiceCenter
END
GO
