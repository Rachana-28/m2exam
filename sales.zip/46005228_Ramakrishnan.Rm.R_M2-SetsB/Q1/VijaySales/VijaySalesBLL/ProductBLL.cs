﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VijaySalesDAL;
using VijaySalesEntity;
using VijaySalesException;


namespace VijaySalesBLL
{
    //Creating BLL Logic for Validation and Insertion
    public class ProductBLL
    {
        private static bool ValidateProduct(Products product)     //Method to validate enterred data
        {
            bool validProduct = true;
            StringBuilder sb = new StringBuilder();
            try
            {
                if (product.SerialNumber == string.Empty)     
                {
                    validProduct = false;
                    sb.Append(Environment.NewLine + "Please enter Serial No");
                }
                else if (product.SerialNumber.Length != 14)
                {
                    validProduct = false;
                    sb.Append("ID should be only 14 characters");
                }
                else if (!Regex.IsMatch(product.SerialNumber, @"[0-9]{4}-[0-9]{4}-[0-9]{4}"))  
                {
                    validProduct = false;
                    sb.Append(Environment.NewLine + "Invalid serial Number format");
                }

                if (product.ProductName == String.Empty)
                {
                    validProduct = false;
                    sb.Append(Environment.NewLine + "Product Name can't be empty");

                }
                else if (!Regex.IsMatch(product.ProductName, "^[A-Z]{1}[a-z]+"))

                {
                    validProduct = false;
                    sb.Append("First letter should be capital");
                }

                if (product.BrandName == String.Empty)
                {
                    validProduct = false;
                    sb.Append(Environment.NewLine + "Brand Name can't be empty");

                }
                else if (!Regex.IsMatch(product.BrandName, "^[A-Z]{1}[a-z]+"))

                {
                    validProduct = false;
                    sb.Append("First letter should be capital");
                }

                if (product.ProductType == string.Empty)     
                {
                    validProduct = false;
                    sb.Append(Environment.NewLine + "Please choose Product Type");
                }

                if (product.ProductDescription == string.Empty)     
                {
                    validProduct = false;
                    sb.Append(Environment.NewLine + "Please provide the Product Description");
                }




                if (product.ProductPrice == String.Empty)
                {
                    validProduct = false;
                    sb.Append(Environment.NewLine + "Product Price can't be empty");

                }
                else if (product.ProductPrice.Length < 0)
                {
                    validProduct = false;
                    sb.Append(Environment.NewLine + "Product Price should be greater than zero");

                }
                


                if (validProduct == false)
                {
                    throw new VijaySalesException.ProductException(sb.ToString());
                }
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validProduct;
        }


        public static int InsertProduct(Products newProduct)
        {
            int DeviceInserted = 0;

            try
            {
                if (ValidateProduct(newProduct))
                {
                    DeviceInserted = ProductDAL.InsertProduct(newProduct);
                }
                else
                {
                    throw new ProductException("Product data is invalid");

                }


            }
            catch (ProductException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return DeviceInserted;
        }
        public static DataTable Display()
        {
            DataTable productSearched = null;

            try
            {
                productSearched = ProductDAL.Display();
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return productSearched;
        }
    }
}
