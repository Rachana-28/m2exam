﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VijaySalesEntity;
using VijaySalesException;
using VijaySalesBLL;
using VijaySalesDAL;
using System.Data;

namespace VijaySalesWpfConsole
{
    /// <summary>
    /// Employee Id : 46005228
    /// Name: RAMAKRISHNAN.RM.R
    /// SET-A-Vijay Sales Products Management System
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        // Getting input from wpf Console and adding it to databse after validation when button clicked
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Products newProduct = new Products();
            try
            {
                newProduct.SerialNumber = serialNumtxt.Text;
                newProduct.ProductName = PNametxt.Text;
                newProduct.BrandName = Bnametxt.Text;
                newProduct.ProductType = PTypetxt.Text;
                newProduct.ProductDescription = descriptiontxt.Text;
                newProduct.ProductPrice = Pricetxt.Text;

                int productInserted = ProductBLL.InsertProduct(newProduct);

                if (productInserted > 0)
                {
                    MessageBox.Show("Product Record Inserted Successfully");
                    //Clear();
                    display();
                }
                else
                    throw new ProductException("Product record not inserted");
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void display()
        {
            DataTable productTable = ProductBLL.Display();
            if (productTable != null)
                DisplayGrid.DataContext = productTable;
            else
                MessageBox.Show("Product not found");
        }
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            display();
        }
    }
}
