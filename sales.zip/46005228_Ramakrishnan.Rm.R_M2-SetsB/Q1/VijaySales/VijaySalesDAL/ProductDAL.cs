﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VijaySalesEntity;
using VijaySalesException;
using System.Configuration;
using System.Data;

namespace VijaySalesDAL
{
    public class ProductDAL
    {
        //Creating Sql Command Connecting with the database
        public static SqlCommand CreateCommand()
        {
            SqlCommand cmd = null;

            try
            {
                string sqlConnectString = ConfigurationManager.ConnectionStrings["ConnectDB"].ConnectionString;
                SqlConnection con = new SqlConnection();
                con.ConnectionString = sqlConnectString;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return cmd;
        }
        // Creating Datatable for datagrid to display detAILS from the database
        public static DataTable Display()
        {
            DataTable ProductDT = null;

            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_displayAllProducts_46005228";


                cmd.Connection.Open();
                SqlDataReader DRproduct = cmd.ExecuteReader();
                if (DRproduct.HasRows)
                {
                    ProductDT = new DataTable();

                    ProductDT.Load(DRproduct);
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ProductDT;
        }
        // Inserting Datas into database through dLL
        public static int InsertProduct(Products newProduct)
        {
            int ProductInserted = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_InsertProduct_46005228";

                cmd.Parameters.AddWithValue("@SerialNumber", newProduct.SerialNumber);
                cmd.Parameters.AddWithValue("@ProductName", newProduct.ProductName);
                cmd.Parameters.AddWithValue("@BrandName", newProduct.BrandName);
                cmd.Parameters.AddWithValue("@ProductType", newProduct.ProductType);
                cmd.Parameters.AddWithValue("@ProductDescription", newProduct.ProductDescription);
                cmd.Parameters.AddWithValue("@Price", newProduct.ProductPrice);

                cmd.Connection.Open();
                ProductInserted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ProductInserted;
        }
    }
}
