create database VijaySales_46005228

create table Products_46005228
(
SerialNumber varchar(14) primary key,
ProductName Varchar(30),
BrandName varchar(20),
ProductType varchar(20),
ProductDescription varchar(100),
Price varchar(20)
)

create proc usp_InsertProduct_46005228
@SerialNumber varchar(14),
@ProductName Varchar(30),
@BrandName varchar(20),
@ProductType varchar(20),
@ProductDescription varchar(100),
@Price varchar(20)
as
insert into Products_46005228(SerialNumber,ProductName,BrandName,ProductType,ProductDescription,Price) 
values(@SerialNumber,@ProductName,@BrandName,@ProductType,@ProductDescription,@Price)

create proc usp_displayAllProducts_46005228
as
select * from Products_46005228

