﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Route_Entities
{
    [Serializable]
        public class Route
    {
        public int RouteId { get; set; }

        public string RouteFrom { get; set; }

        public string RouteTo { get; set; }

        public string BusNo { get; set; }

        public string BusType{ get; set; }

        public int Capacity { get; set; }

        public int Fare { get; set; }

       
    }
}
