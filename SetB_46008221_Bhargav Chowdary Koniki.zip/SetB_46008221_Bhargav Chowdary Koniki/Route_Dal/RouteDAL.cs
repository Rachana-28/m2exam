﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Route_Entities;
using Route_Exceptions;

namespace Route_Dal
{
    public class RouteDAL
    {

        public static List<Route> routeList = new List<Route>();



        public bool AddRouteDAL(Route newroute)

        {

            bool routeAdded = false;

            try

            {

                routeList.Add(newroute);

                routeAdded = true;

            }

            catch (SystemException ex)

            {

                throw new RouteException(ex.Message);

            }

            return routeAdded;



        }



        public List<Route> GetAllRouteDAL()

        {

            return routeList;

        }



        public Route SearchRouteDAL(int searchRouteId)

        {

            Route searchRoute = null;

            try

            {

                searchRoute = routeList.Find(route=> route.RouteId == searchRouteId);

            }

            catch (SystemException ex)

            {

                throw new RouteException(ex.Message);

            }

            return searchRoute;

        }



        public bool UpdateRouteDAL(Route updateRoute)

        {

            bool routeUpdated = false;

            try

            {

                for (int i = 0; i < routeList.Count; i++)

                {

                    if (routeList[i].RouteId == updateRoute.RouteId)

                    {

                        updateRoute.RouteFrom = routeList[i].RouteFrom;
                        updateRoute.RouteTo = routeList[i].RouteTo;
                        updateRoute.BusNo = routeList[i].BusNo;
                        updateRoute.BusType = routeList[i].BusType;
                        updateRoute.Capacity = routeList[i].Capacity;
                        updateRoute.Fare = routeList[i].Fare;

                        routeUpdated = true;

                    }

                }

            }

            catch (SystemException ex)

            {

                throw new RouteException(ex.Message);

            }

            return routeUpdated;



        }



        public bool DeleteRouteDAL(int deleteRouteId)

        {

            bool routeDeleted = false;

            try

            {

                Route deleteRoute = routeList.Find(route => route.RouteId == deleteRouteId);



                if (deleteRoute != null)

                {

                    routeList.Remove(deleteRoute);

                    routeDeleted = true;

                }

            }

            catch (Exception ex)

            {

                throw new RouteException(ex.Message);

            }

            return routeDeleted;



        }

    }
}
