﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Route_Bal;
using Route_Entities;
using Route_Exceptions;

namespace Route_PL
{
    class Program
    {
        static void Main(string[] args)
        {

            int choice;

            do

            {

                PrintMenu();

                Console.WriteLine("Enter your Choice:");

                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)

                {

                    case 1:

                        AddRoute();

                        break;

                    case 2:

                        SearchRouteByID();

                        break;

                    case 3:

                        UpdateRoute();

                        break;

                    case 4:

                        DeleteRoute();

                        break;

                    case 5:

                        return;

                    default:

                        Console.WriteLine("Invalid Choice");

                        break;

                }

            } while (choice != -1);

        }



        private static void DeleteRoute()

        {

            try

            {

                int deleteRouteId;

                Console.WriteLine("Enter RouteId to Delete:");

                deleteRouteId = Convert.ToInt32(Console.ReadLine());

                Route deleteRoute = RouteBAL.SearchRouteBAL(deleteRouteId);

                if (deleteRoute != null)

                {

                    bool routedeleted = RouteBAL.DeleteRouteBAL(deleteRouteId);

                    if (routedeleted)

                        Console.WriteLine("Route Deleted");

                    else

                        Console.WriteLine("Route not Deleted ");

                }

                else

                {

                    Console.WriteLine("No Route Details Available");

                }





            }

            catch (RouteException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }



        private static void UpdateRoute()

        {

            try

            {

                int updateRouteId;

                Console.WriteLine("Enter RouteId to Update Details:");

                updateRouteId = Convert.ToInt32(Console.ReadLine());

                Route updatedRoute = RouteBAL.SearchRouteBAL(updateRouteId);

                if (updatedRoute != null)

                {

                    Console.WriteLine("Update RouteFrom :");

                    updatedRoute.RouteFrom = Console.ReadLine();

                    Console.WriteLine("Update RouteTo:");

                    updatedRoute.RouteTo = Console.ReadLine();

                    Console.WriteLine("Update BusNo :");

                    updatedRoute.BusNo = Console.ReadLine();

                    Console.WriteLine("Update Bustype :");

                    updatedRoute.BusType = Console.ReadLine();

                    Console.WriteLine("Update Capacity :");

                    updatedRoute.Capacity =Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Update Fare :");

                    updatedRoute.Fare = Convert.ToInt32(Console.ReadLine());

                    bool routeUpdated = RouteBAL.UpdateRouteBAL(updatedRoute);

                    if (routeUpdated)

                        Console.WriteLine("Route Details Updated");

                    else

                        Console.WriteLine("Route Details not Updated ");

                }

                else

                {

                    Console.WriteLine("No Route Details Available");

                }





            }

            catch (RouteException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }



        private static void SearchRouteByID()

        {

            try

            {

                int searchRouteId;

                Console.WriteLine("Enter RouteId to Search:");

                searchRouteId = Convert.ToInt32(Console.ReadLine());

                Route searchRoute = RouteBAL.SearchRouteBAL(searchRouteId);

                if (searchRoute != null)

                {

                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("RouteId\t\tRouteFrom\t\tRouteTo\t\tBusNo\t\tBusType\t\tCapacity\t\tFare");

                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("{0}\t\t{1}\t\t{2}}\t\t{3}}\t\t{4}}\t\t{5}}\t\t{6}", searchRoute.RouteId, searchRoute.RouteFrom, searchRoute.RouteTo,searchRoute.BusNo,searchRoute.BusType,searchRoute.Capacity,searchRoute.Fare);

                    Console.WriteLine("******************************************************************************");

                }

                else

                {

                    Console.WriteLine("No Route Details Available");

                }



            }

            catch (RouteException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }





        private static void ListAllRoutes()

        {

            try

            {

                List<Route> routeList = RouteBAL.GetAllRoutesBAL();

                if (routeList != null)

                {

                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("RouteId\t\tRouteFrom\t\tRouteTo\t\tBusNo\t\tBusType\t\tCapacity\t\tFare");

                    Console.WriteLine("******************************************************************************");

                    foreach (Route route in routeList)

                    {

                        Console.WriteLine("{0}\t\t{1}\t\t{2}}\t\t{3}}\t\t{4}}\t\t{5}}\t\t{6}", route.RouteId,route.RouteFrom,route.RouteTo,route.BusNo, route.BusType, route.Capacity, route.Fare);

                    }

                    Console.WriteLine("******************************************************************************");



                }

                else

                {

                    Console.WriteLine("No route Details Available");

                }

            }

            catch (RouteException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }



        private static void AddRoute()

        {

            try

            {

                Route newRoute = new Route();

                Console.WriteLine("Enter RouteId :");

                newRoute.RouteId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter RouteFrom :");

                newRoute.RouteFrom = Console.ReadLine();

                Console.WriteLine("Enter RouteTo:");

                newRoute.RouteTo = Console.ReadLine();

                Console.WriteLine("Enter BusNo :");

                newRoute.BusNo = Console.ReadLine();

                Console.WriteLine("Enter Bustype :");

                newRoute.BusType = Console.ReadLine();

                Console.WriteLine("Enter Capacity :");

                newRoute.Capacity = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Fare :");

                newRoute.Fare = Convert.ToInt32(Console.ReadLine());



                bool routeAdded = RouteBAL.AddRouteBAL(newRoute);

                if (routeAdded)

                    Console.WriteLine("Route Added");

                else

                    Console.WriteLine("Route not Added");

            }

            catch (RouteException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }



        private static void PrintMenu()

        {

            Console.WriteLine("\n***********Bus Route Check Menu***********");

            Console.WriteLine("1. Add Route");

            Console.WriteLine("2. Search Route by ID");

            Console.WriteLine("3. Update Route");

            Console.WriteLine("4. Delete Route");

            Console.WriteLine("5. Exit");

            Console.WriteLine("******************************************\n");



        }

    }

}
    

