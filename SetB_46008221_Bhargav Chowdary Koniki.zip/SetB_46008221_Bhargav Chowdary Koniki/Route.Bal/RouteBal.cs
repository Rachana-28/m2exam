﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Route_Dal;
using Route_Entities;
using Route_Exceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Route_Bal
{
    public class RouteBAL
    {
        static string filePath = "Routes.ser";

        private static void Serialize_Binary(string filePath, List<Route> routes)

        {

            FileStream fileStream = new FileStream(filePath, FileMode.Create);

            BinaryFormatter binaryFormatter = new BinaryFormatter();

            binaryFormatter.Serialize(fileStream, routes);

            fileStream.Close();

        }

        private static List<Route> Deserialize_Binary(string filePath)

        {

            FileStream fileStream = new FileStream(filePath, FileMode.Open);

            BinaryFormatter binaryFormatter = new BinaryFormatter();

            List<Route> routes = (List<Route>)binaryFormatter.Deserialize(fileStream);

            fileStream.Close();

            return routes;

        }

        private static bool ValidateRoute(Route route)

        {

            StringBuilder sb = new StringBuilder();

            bool validRoute = true;

            if (route.RouteId <= 0)

            {

                validRoute = false;

                sb.Append(Environment.NewLine + "Invalid RouteId");
            }

            if (route.RouteFrom == string.Empty)

            {

                validRoute = false;

                sb.Append(Environment.NewLine + "RouteFrom Required");
            }

            if (route.RouteTo == string.Empty)

            {

                validRoute = false;


                sb.Append(Environment.NewLine + "This Required");
            }
            if (route.BusType == string.Empty)


            {

                validRoute = false;

                sb.Append(Environment.NewLine + "BusType Required");
            }


            if (route.BusNo == string.Empty)


            {

                validRoute = false;

                sb.Append(Environment.NewLine + "Enter valid Bus Number");
            }
            if (route.Capacity <= 0)

            {

                validRoute = false;

                sb.Append(Environment.NewLine + "Enter capacity according to seats limit");

            }
            if (route.Fare >= 0)

            {

                validRoute = false;

                sb.Append(Environment.NewLine + "RouteTo Required");



            }


            if (validRoute == false)

                throw new RouteException(sb.ToString());

            return validRoute;

        }



        public static bool AddRouteBAL(Route newRoute)

        {

            bool routeAdded = false;

            try

            {

                if (ValidateRoute(newRoute))

                {

                    RouteDAL routeDAL = new RouteDAL();

                    routeAdded = routeDAL.AddRouteDAL(newRoute);



                    //Serialize here // call the function which is private method

                    List<Route> ro = routeDAL.GetAllRouteDAL();

                    Serialize_Binary(filePath, ro);

                }

            }

            catch (RouteException)

            {

                throw;

            }

            catch (Exception ex)

            {

                throw ex;

            }



            return routeAdded;

        }



        public static List<Route> GetAllRoutesBAL()

        {

            List<Route> routeList = null;

            try

            {

                RouteDAL guestDAL = new RouteDAL();

                //deserialize



                routeList = Deserialize_Binary(filePath);

            }

            catch (RouteException ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return routeList;

        }



        public static Route SearchRouteBAL(int searchRouteId)

        {

            Route searchRoute = null;

            try

            {

                RouteDAL routeDAL = new RouteDAL();

                searchRoute = routeDAL.SearchRouteDAL(searchRouteId);

            }

            catch (RouteException ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return searchRoute;



        }



        public static bool UpdateRouteBAL(Route updateRoute)

        {

            bool routeUpdated = false;

            try

            {

                if (ValidateRoute(updateRoute))

                {

                    RouteDAL guestDAL = new RouteDAL();

                    routeUpdated = guestDAL.UpdateRouteDAL(updateRoute);

                    //call a method to serialize

                    List<Route> ro = GetAllRoutesBAL();

                    Serialize_Binary(filePath, ro);

                }

            }

            catch (RouteException)

            {

                throw;

            }

            catch (Exception ex)

            {

                throw ex;

            }



            return routeUpdated;

        }



        public static bool DeleteRouteBAL(int deleteRouteId)

        {

            bool routeDeleted = false;

            try

            {

                if (deleteRouteId > 0)

                {

                    RouteDAL routeDAL = new RouteDAL();

                    routeDeleted = routeDAL.DeleteRouteDAL(deleteRouteId);

                }

                else

                {

                    throw new RouteException("Invalid route ID");

                }

            }

            catch (RouteException)

            {

                throw;

            }

            catch (Exception ex)

            {

                throw ex;

            }



            return routeDeleted;

        }



    }

}



