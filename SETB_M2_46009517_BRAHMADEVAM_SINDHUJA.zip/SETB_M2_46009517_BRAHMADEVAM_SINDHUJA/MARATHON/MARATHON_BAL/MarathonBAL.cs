﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MARATHON_ENTITIES;
using MARATHON_EXCEPTION;
using MARATHON_DAL;
using System.Text.RegularExpressions;

namespace MARATHON_BAL
{
    public class MarathonBAL
    {
        public static bool ValidateEmployee(MarathonEntity newMar)
        {
            StringBuilder message = new StringBuilder();
            bool validEmployee = true;

            try
            {
                if (newMar.EmployeeId == string.Empty)
                {
                    message.Append("Employee Id should be provided\n");
                    validEmployee = false;
                }
                else if (!Regex.IsMatch(newMar.EmployeeId, "[0-9]{6}"))
                {
                    message.Append("Employee Id should contain 6 digits exactly\n");
                    validEmployee = false;
                }
                if (newMar.EmpName == string.Empty)
                {
                    message.Append("Employee name should be provided\n");
                    validEmployee = false;
                }
                else if (!Regex.IsMatch(newMar.EmpName, "^[A-Z][a-z]+"))
                {
                    message.Append("Employee name should start with Capital letter and it should have alphabets only\n");
                    validEmployee = false;
                }


                if (newMar.Gender == string.Empty)
                {
                    message.Append("Gender should be provided\n");
                    validEmployee = false;
                }

                if (newMar.ContactNo == String.Empty)
                {
                    message.Append("Contact number should be provided\n");
                    validEmployee = false;
                }
                else if (!Regex.IsMatch(newMar.ContactNo, "[7-9][0-9]{9}"))
                {
                    message.Append("Contact number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    validEmployee = false;
                }

                if (validEmployee == false)
                {
                    throw new MarathonException(message.ToString());
                }
            }
            catch (MarathonException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validEmployee;
        }
        public static int RegisterEmployee(MarathonEntity newMar)
        {
            int EmpInserted = 0;

            try
            {
                if (ValidateEmployee(newMar))
                {
                    EmpInserted = MarathonDAL.RegisterEmployee(newMar);
                }
                else
                    throw new MarathonException("Employee data is invalid");
            }
            catch (MarathonException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return EmpInserted;
        }
    }
}




