﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MARATHON_EXCEPTION
{
    public class  MarathonException: ApplicationException
    {
        public MarathonException() : base()
        {

        }
        public MarathonException(string msg) : base(msg)
        {

        }
        public MarathonException(string msg, Exception innerexception) : base(msg, innerexception)
        {

        }
    }
}
