﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MARATHON_ENTITIES;
using MARATHON_EXCEPTION;

namespace MARATHON_DAL
{
    public class MarathonDAL
    {
        public static SqlCommand CreateCommand()
        {
            SqlCommand cmd = null;

            try
            {
                string sqlConnectString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;

                //  string s= @"seserver=ndamssql\sqlilearn;databa=Training_19Sep19_Pune;uid=sqluser; pwd=sqluser"/>
                SqlConnection con = new SqlConnection();
                // con.ConnectionString = @"Data Source=sindhuja-PC;Database=Training; integrated security=true;";
                con.ConnectionString = sqlConnectString;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return cmd;
        }
        public static int RegisterEmployee(MarathonEntity newMar)
        {
            int EmpInserted = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "[09517].[usp_InsertEmployee]";
                cmd.Parameters.AddWithValue("@ID", newMar.EmployeeId);
                cmd.Parameters.AddWithValue("@Name", newMar.EmpName);
                cmd.Parameters.AddWithValue("@Gender", newMar.Gender);
                cmd.Parameters.AddWithValue("@Location", newMar.Location);
                cmd.Parameters.AddWithValue("@Contact", newMar.ContactNo);
                cmd.Parameters.AddWithValue("@BloodGroup", newMar.BloodGrp);
                cmd.Parameters.AddWithValue("@Coverage",newMar.Coverage);

                cmd.Connection.Open();
                EmpInserted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (MarathonException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return EmpInserted;
        }
    }

}
