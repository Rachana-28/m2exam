use Training_19Sep19_Pune
go

create table [09517].Marathon
(
EmployeeId varchar(6) primary key not null,
Name varchar(15),
Gender varchar(6),
Location varchar(10),
Contact varchar(10),
BloodGroup varchar(6),
Coverage varchar(6)
);

-----------------------------------------------------------------


USE Training_19Sep19_Pune
GO

create procedure [09517].[usp_InsertEmployee]
(
@ID varchar(6), 
@Name varchar(15),
@Gender varchar(6),
@Location varchar(10),
@Contact varchar(10),
@BloodGroup varchar(6),
@Coverage varchar(6)
)
AS 
begin
Insert into [09517].Marathon values(@ID,@Name,@Gender, @Location, @Contact, @BloodGroup, @Coverage )
end

--------------------------------------------------------------------------
select * from [09517].Marathon


----------------------------------------------------------------

