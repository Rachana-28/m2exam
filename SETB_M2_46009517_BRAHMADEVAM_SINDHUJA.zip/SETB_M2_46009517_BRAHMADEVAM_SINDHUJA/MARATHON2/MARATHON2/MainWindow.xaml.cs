﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MARATHON2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

       Marathon empEntity;

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            dgEmployee.ItemsSource = (from data in [09517].Marathon.Marathon2
                                       where data.Location == "Chennai"
                                      select new
                                      {
                                          data.EmpID,
                                          data.EmpName,
                                          data.Gender,
                                          data.Location,
                                          data.ContactNo,
                                          data.BloodGroup,
                                          data.Coverage,
                                      }).ToList();
        }

        private void BtnDisplay_Click(object sender, RoutedEventArgs e)
        {
            empEntity = new Marathon();
            dgEmployee.DataContext = empEntity.[09517].Marathon.Where(x => x.Location == "Chennai" && x.Coverage == "10 KM").ToList();
            var query = empEntity.[09517].Marathon.Count(x => x.Location == "Chennai" && x.Coverage == "10 KM");
            MessageBox.Show("No of employees who have registered for 10 Kms coverage of Marathon in Chennai : "
        }
    }
}

